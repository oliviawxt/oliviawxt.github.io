$(document).ready(function() {

    $("a#acting").click(function() {
        $("#act").slideToggle(300);
    });

    $("a#coming").click(function() {
        $("#come").slideToggle(300);
    });

    $("a#purchase").click(function() {
        $("#info").slideToggle(300);
    });

    $("a#recommendation").click(function() {
        $("#rec").slideToggle(300);
    });

    $("a#analysis").click(function() {
        $("#ana").slideToggle(300);
    });


});